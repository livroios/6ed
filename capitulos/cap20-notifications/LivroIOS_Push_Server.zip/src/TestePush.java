import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;
import com.notnoop.apns.PayloadBuilder;

public class TestePush {

	public static void main(String[] args) {
		// ipad
		String deviceToken = "3af1989b fb28d2c9 c0b3fa3e 330fb26e eb56dd53 d649b57f 75e7eb1d 8a36ccc3";
		String certificadoP12 = "PushCertificates3aEdicao.p12";
		String senhaCertificado = "lecheta123";

		try {
			// Cria o servi�o do APNS, validando o certificado
			ApnsService service = APNS.newService().withCert(certificadoP12, senhaCertificado).withSandboxDestination().build();
			service.start();

			// Texto da Mensagem
			String msg = "Mensagem remota para o iPad 2";
			// N�mero badge
			int badge = 5;

			// Cria a mensagem (payload)
			PayloadBuilder payloadBuilder = APNS.newPayload();
			payloadBuilder = payloadBuilder.badge(badge).alertBody(msg);
			if (payloadBuilder.isTooLong()) {
				payloadBuilder = payloadBuilder.shrinkBody();
			}
			String payload = payloadBuilder.build();

			// Enva a mensagem para o device token informado
			service.push(deviceToken, payload);
			System.out.println("Mensagem [" + msg + "] enviada, badge [" + badge + "]");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}